# Exercise 2 (Peter Koll, Jonas Wagner)

Examine the output. Is there any useful information regarding dependence analysis? What are your findings?

Yes, there are useful informations about dependencies within the for loops. Since analysis.c contains only one for-loop with a dependency. The information we get from the analysis tools are about the depth and direction within the loop. Depth = 4, Direction = negative.
